from starlette.websockets import WebSocket

log_websockets: list[WebSocket] = []
