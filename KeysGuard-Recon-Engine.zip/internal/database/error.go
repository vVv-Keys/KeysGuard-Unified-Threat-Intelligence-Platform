package database

type DatabaseError string

const ErrUniqueConstraintFailed = "UNIQUE constraint failed"
